.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


.. _namespace-AeonDigital-EnGarde-Interfaces:

Interfaces
==========

\AeonDigital\EnGarde\Interfaces


Interfaces
----------

.. toctree::
	:maxdepth: 6
	
	iApplication <iApplication>
	iController <iController>
	iMiddleware <iMiddleware>
	iMimeHandler <iMimeHandler>
	iRequestHandler <iRequestHandler>
	iResponseHandler <iResponseHandler>


