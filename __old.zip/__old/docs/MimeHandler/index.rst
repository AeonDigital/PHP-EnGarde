.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


.. _namespace-AeonDigital-EnGarde-MimeHandler:

MimeHandler
===========

\AeonDigital\EnGarde\MimeHandler


Classes
-------

.. toctree::
	:maxdepth: 6
	
	aMimeHandler <aMimeHandler>
	CSV <CSV>
	HTML <HTML>
	JSON <JSON>
	PDF <PDF>
	TXT <TXT>
	XHTML <XHTML>
	XLS <XLS>
	XLSX <XLSX>
	XML <XML>


